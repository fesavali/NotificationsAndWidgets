# NotificationsAndWidgets
Enhancing UX with Notifications and App Widgets
